﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ZalinschiMaratona
{
    class unMaratona
    {
        public string NomeAtleta { get; set; }
        public string Appartenenza { get; set; }
        public string Tempo { get; set; }
        public string Citta { get; set; }
    }
}
